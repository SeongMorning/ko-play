CREATE DATABASE  IF NOT EXISTS `koplay` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `koplay`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b302.p.ssafy.io    Database: koplay
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avatar`
--

DROP TABLE IF EXISTS `avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar` (
  `avatar_idx` bigint NOT NULL AUTO_INCREMENT,
  `avatar_file` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `nation_idx` bigint NOT NULL,
  PRIMARY KEY (`avatar_idx`),
  KEY `FKnj8ue00xfanbhf5g0m78pbyvm` (`nation_idx`),
  CONSTRAINT `FKnj8ue00xfanbhf5g0m78pbyvm` FOREIGN KEY (`nation_idx`) REFERENCES `nation` (`nation_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar`
--

LOCK TABLES `avatar` WRITE;
/*!40000 ALTER TABLE `avatar` DISABLE KEYS */;
INSERT INTO `avatar` VALUES (47,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/koreaFlag.png','2024-08-14 17:03:41',0,1),(48,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/koreaMask1.png','2024-08-14 17:03:42',0,1),(49,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/koreaMask2.png','2024-08-14 17:03:42',0,1),(50,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/koreaMask3.png','2024-08-14 17:03:43',0,1),(51,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/koreaMask4.png','2024-08-14 17:03:44',0,1),(52,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/koreaMask5.png','2024-08-14 17:03:45',0,1),(53,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/chinaFlag.png','2024-08-14 17:06:19',0,4),(54,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/chinaMask1.png','2024-08-14 17:06:20',0,4),(55,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/chinaMask2.png','2024-08-14 17:06:23',0,4),(56,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/chinaMask3.png','2024-08-14 17:06:25',0,4),(57,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/chinaMask4.png','2024-08-14 17:06:26',0,4),(58,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/chinaMask5.png','2024-08-14 17:06:26',0,4),(59,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandFlag.png','2024-08-14 17:06:32',0,2),(60,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandMask1.png','2024-08-14 17:06:33',0,2),(61,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandMask2.png','2024-08-14 17:06:34',0,2),(62,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandMask3.png','2024-08-14 17:06:34',0,2),(63,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandMask4.png','2024-08-14 17:06:35',0,2),(64,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/vietnamFlag.png','2024-08-14 17:06:40',0,3),(65,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/vietnamMask1.png','2024-08-14 17:06:41',0,3),(66,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/vietnamMask2.png','2024-08-14 17:06:41',0,3),(67,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/vietnamMask3.png','2024-08-14 17:06:42',0,3),(68,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandHat1.png','2024-08-15 23:33:08',0,2),(69,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/thailandHat2.png','2024-08-15 23:33:08',0,2),(70,'https://ko-play.s3.ap-northeast-2.amazonaws.com/avatar/vietnamHat1.png','2024-08-15 23:33:09',0,3);
/*!40000 ALTER TABLE `avatar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  9:04:14
