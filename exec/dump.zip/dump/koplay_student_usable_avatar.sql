CREATE DATABASE  IF NOT EXISTS `koplay` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `koplay`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b302.p.ssafy.io    Database: koplay
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student_usable_avatar`
--

DROP TABLE IF EXISTS `student_usable_avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_usable_avatar` (
  `student_usable_avatar_idx` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current_use` bit(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `update_date` datetime(6) DEFAULT NULL,
  `avatar_idx` bigint NOT NULL,
  `nation_idx` bigint NOT NULL,
  `student_idx` bigint NOT NULL,
  PRIMARY KEY (`student_usable_avatar_idx`),
  KEY `FKd5vh3okwackjqpaivcn5cy0ns` (`avatar_idx`),
  KEY `FK6gc7x6pnvloqkn9x4x33s3exs` (`nation_idx`),
  KEY `FKl1m34wuhxfjwwjy6hdua5o2u4` (`student_idx`),
  CONSTRAINT `FK6gc7x6pnvloqkn9x4x33s3exs` FOREIGN KEY (`nation_idx`) REFERENCES `nation` (`nation_idx`),
  CONSTRAINT `FKd5vh3okwackjqpaivcn5cy0ns` FOREIGN KEY (`avatar_idx`) REFERENCES `avatar` (`avatar_idx`),
  CONSTRAINT `FKl1m34wuhxfjwwjy6hdua5o2u4` FOREIGN KEY (`student_idx`) REFERENCES `student` (`student_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_usable_avatar`
--

LOCK TABLES `student_usable_avatar` WRITE;
/*!40000 ALTER TABLE `student_usable_avatar` DISABLE KEYS */;
INSERT INTO `student_usable_avatar` VALUES (115,'2024-08-16 00:48:00',_binary '',0,NULL,47,1,7),(116,'2024-08-16 00:48:01',_binary '\0',0,NULL,48,1,7),(117,'2024-08-16 00:48:02',_binary '\0',0,NULL,49,1,7),(118,'2024-08-16 00:48:02',_binary '\0',0,NULL,50,1,7),(119,'2024-08-16 00:48:03',_binary '\0',0,NULL,51,1,7),(120,'2024-08-16 00:48:04',_binary '',0,NULL,52,1,7),(121,'2024-08-16 00:48:06',_binary '',0,NULL,53,4,7),(122,'2024-08-16 00:48:07',_binary '',0,NULL,54,4,7),(123,'2024-08-16 00:48:07',_binary '',0,NULL,55,4,7),(124,'2024-08-16 00:48:08',_binary '',0,NULL,56,4,7),(125,'2024-08-16 00:48:09',_binary '\0',0,NULL,57,4,7),(126,'2024-08-16 00:48:10',_binary '',0,NULL,58,4,7),(127,'2024-08-16 00:48:11',_binary '',0,NULL,59,4,7),(128,'2024-08-16 00:48:12',_binary '',0,NULL,60,4,7),(129,'2024-08-16 00:48:13',_binary '',0,NULL,61,4,7),(130,'2024-08-16 00:48:13',_binary '',0,NULL,62,4,7),(131,'2024-08-16 00:48:14',_binary '',0,NULL,63,4,7),(132,'2024-08-16 00:48:15',_binary '\0',0,NULL,64,4,7),(133,'2024-08-16 00:48:16',_binary '',0,NULL,65,4,7),(134,'2024-08-16 00:48:17',_binary '',0,NULL,66,4,7),(135,'2024-08-16 00:48:17',_binary '',0,NULL,67,4,7),(136,'2024-08-16 00:48:19',_binary '',0,NULL,68,2,7),(137,'2024-08-16 00:48:20',_binary '',0,NULL,69,2,7),(138,'2024-08-16 00:48:20',_binary '',0,NULL,70,3,7),(139,'2024-08-16 03:39:12',_binary '',0,NULL,48,1,14);
/*!40000 ALTER TABLE `student_usable_avatar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  9:04:08
