CREATE DATABASE  IF NOT EXISTS `koplay` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `koplay`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b302.p.ssafy.io    Database: koplay
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `word`
--

DROP TABLE IF EXISTS `word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `word` (
  `word_idx` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `img_url` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `word_china` varchar(255) NOT NULL,
  `word_difficulty` int NOT NULL,
  `word_kor` varchar(255) NOT NULL,
  `word_thailand` varchar(255) NOT NULL,
  `word_vietnam` varchar(255) NOT NULL,
  PRIMARY KEY (`word_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `word`
--

LOCK TABLES `word` WRITE;
/*!40000 ALTER TABLE `word` DISABLE KEYS */;
INSERT INTO `word` VALUES (19,'2024-08-05 03:53:38','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/tiger.png',0,'老虎',1,'호랑이','เสือ','con hổ'),(20,'2024-08-05 03:53:40','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/rabbit.jpg',0,'兔子',1,'토끼','กระต่าย','con thỏ'),(21,'2024-08-05 03:53:52','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/lion.png',0,'狮子',1,'사자','สิงโต','sư tử'),(22,'2024-08-05 03:53:59','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/giraffe.jpg',0,'长颈鹿',1,'기린','ยีราฟ','hươu cao cổ'),(23,'2024-08-05 03:54:01','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/penguin.jpg',0,'企鹅',1,'펭귄','เพนกวิน','Chim cánh cụt'),(24,'2024-08-05 03:54:05','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/ant.png',0,'蚂蚁',1,'개미','มด','kiến'),(25,'2024-08-05 03:54:07','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/elephant.png',0,'大象',1,'코끼리','ช้าง','voi'),(26,'2024-08-05 03:54:10','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/horse.png',0,'马匹',1,'말','ม้า','Ngựa'),(27,'2024-08-05 03:54:20','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/dolphin.png',0,'海豚',1,'돌고래','โลมา','Cá heo'),(28,'2024-08-05 03:54:21','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/dog.png',0,'小狗',1,'강아지','ลูกสุนัข','Chó con'),(68,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/cloud.jfif',0,'云',1,'구름','เมฆ','bóng mây'),(69,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/button.jfif',0,'纽扣系列',1,'단추','ปุ่ม','Nút'),(70,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/chick.jfif',0,'小鸡',1,'병아리','เจี๊ยบ','Gà con'),(71,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/shoes.jfif',0,'皮鞋类',1,'신발','รองเท้า','giày'),(72,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/plum.jfif',0,'梅子',1,'자두','ลูกพลัม','quả mận'),(73,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/rainbow.jfif',0,'彩虹',1,'무지개','เรนโบว์','cầu vồng'),(74,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/bycicle.jfif',0,'自行车',1,'자전거','จักรยาน','xe đạp'),(75,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/ballon.jfif',0,'热气球',1,'풍선','บอลลูน','Bóng bay'),(76,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/nose.jfif',0,'鼻梁儿',1,'코','จมูก','mũi'),(77,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/mouth.jfif',0,'口 口',1,'입','ปาก','Miệng'),(78,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/ear.jfif',0,'侧耳倾听',1,'귀','หู','sự lắng nghe'),(79,'2024-08-07 13:10:28','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/Sheep.jfif',0,'羊群',1,'양','แกะ','người nhút nhát'),(80,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/cow.jfif',0,'牛',1,'소','วัว','bò cái'),(81,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/apple.jfif',0,'苹果',1,'사과','แอปเปิ้ล','quả táo'),(82,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/stair.jfif',0,'楼梯',2,'계단','บันได','cầu thang'),(83,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/whale.jfif',0,'鲸类',2,'고래','ปลาวาฬ','cá voi'),(84,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/eyebrow.jpg',0,'眉毛系列',2,'눈썹','คิ้ว','Lông mày'),(85,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/fountain.jfif',0,'喷泉',2,'분수','น้ำพุ','một đài phun nước'),(86,'2024-08-07 13:10:29','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',0,'铅笔',2,'연필','ดินสอ','viết bằng bút chì'),(87,'2024-08-07 13:22:46','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/cry.jfif',0,'泪流满面',2,'눈물','น้ำตา','Nước mắt'),(88,'2024-08-07 13:25:32','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/banana.jfif',0,'香蕉',2,'바나나','กล้วย','quả chuối'),(89,'2024-08-07 13:25:34','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/grape.jfif',0,'葡萄',2,'포도','องุ่น','quả nho'),(90,'2024-08-07 13:25:34','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/ant.jfif',0,'蚂蚁',2,'개미','มด','kiến'),(91,'2024-08-07 13:25:35','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/butterfly.jfif',0,'蝴蝶结',2,'나비','ผีเสื้อ','con bướm'),(92,'2024-08-07 13:25:36','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/giraffe.jfif',0,'长颈鹿',2,'기린','ยีราฟ','hươu cao cổ'),(93,'2024-08-07 13:25:36','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/crocodile.jfif',0,'鳄鱼属',2,'악어','จระเข้','cá sấu'),(94,'2024-08-07 13:25:37','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/airplain.jfif',0,'飞机',2,'비행기','เครื่องบิน','máy bay'),(95,'2024-08-07 13:25:38','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/bed.jfif',0,'床',2,'침대','เตียง','Giường ngủ'),(96,'2024-08-07 13:52:46','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/well.jfif',0,'洞穴',3,'우물','ถ้ำ','hang động'),(97,'2024-08-07 13:52:47','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/slide.jfif',0,'幻灯片',3,'미끄럼틀','ภาพนิ่ง','Trượt'),(98,'2024-08-07 13:52:59','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/hamster.jfif',0,'仓鼠属',3,'햄스터','หนูแฮมสเตอร์','Chuột chù'),(99,'2024-08-07 13:53:00','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/dandelion.jfif',0,'蒲公英',3,'민들레','ดอกแดนดิไลออน','bồ công anh'),(100,'2024-08-07 13:53:01','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/squirrel.jfif',0,'松鼠属',3,'다람쥐','กระรอก','Sóc chuột'),(101,'2024-08-07 13:53:02','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/frug.jfif',0,'蛙类',3,'개구리','กบ','con ếch'),(102,'2024-08-07 13:53:02','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/peach.jfif',0,'佩奇',3,'복숭아','พีช','Đào'),(103,'2024-08-07 13:53:03','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/squid.jfif',0,'乌贼',3,'오징어','ปลาหมึก','ปลาหมึก'),(104,'2024-08-07 13:53:04','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/fireTruck.jfif',0,'消防车',3,'소방차','รถดับเพลิง','xe chữa cháy'),(105,'2024-08-07 13:53:05','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/earth.jfif',0,'大地',3,'지구','ดิน','đất'),(106,'2024-08-07 13:53:05','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/parasol.jfif',0,'遮阳伞',3,'파라솔','พาราโซล','Cây dù che nắng'),(107,'2024-08-07 13:53:06','https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level3/ladle.jfif',0,'汤勺',3,'국자','ทัพพี','vá múc canh');
/*!40000 ALTER TABLE `word` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  9:04:10
