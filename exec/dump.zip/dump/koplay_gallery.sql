CREATE DATABASE  IF NOT EXISTS `koplay` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `koplay`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11b302.p.ssafy.io    Database: koplay
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gallery` (
  `gallery_idx` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `snapshot` varchar(255) DEFAULT NULL,
  `parent_idx` bigint NOT NULL,
  `student_idx` bigint NOT NULL,
  PRIMARY KEY (`gallery_idx`),
  KEY `FKj18nkkc599mvli99192ltm417` (`parent_idx`),
  KEY `FK8ic65uxjb2p7oust4wdwwtu4j` (`student_idx`),
  CONSTRAINT `FK8ic65uxjb2p7oust4wdwwtu4j` FOREIGN KEY (`student_idx`) REFERENCES `student` (`student_idx`),
  CONSTRAINT `FKj18nkkc599mvli99192ltm417` FOREIGN KEY (`parent_idx`) REFERENCES `parent` (`parent_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery`
--

LOCK TABLES `gallery` WRITE;
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
INSERT INTO `gallery` VALUES (1,'2024-08-03 13:37:15',0,'https://i.namu.wiki/i/pF2ydeJ4q4jbB6d0hpseI2RjQEfDmx1DGBefpgfG6EX5b_Qa20MRrRXi8V5axWzUjDNjPXiKSph9zxHnlsSt5muPfOuXe1mlJMTzysEcJUlyX3M5E3FPDB877q4OYecCrl6Cw5pTzDDL5sf6KfnK7A.webp',1,1),(2,'2024-08-03 13:37:15',0,'https://i.namu.wiki/i/pF2ydeJ4q4jbB6d0hpseI2RjQEfDmx1DGBefpgfG6EX5b_Qa20MRrRXi8V5axWzUjDNjPXiKSph9zxHnlsSt5muPfOuXe1mlJMTzysEcJUlyX3M5E3FPDB877q4OYecCrl6Cw5pTzDDL5sf6KfnK7A.webp',2,2),(3,'2024-08-03 13:37:15',0,'https://i.namu.wiki/i/pF2ydeJ4q4jbB6d0hpseI2RjQEfDmx1DGBefpgfG6EX5b_Qa20MRrRXi8V5axWzUjDNjPXiKSph9zxHnlsSt5muPfOuXe1mlJMTzysEcJUlyX3M5E3FPDB877q4OYecCrl6Cw5pTzDDL5sf6KfnK7A.webp',3,3),(4,'2024-08-03 13:37:15',0,'https://i.namu.wiki/i/pF2ydeJ4q4jbB6d0hpseI2RjQEfDmx1DGBefpgfG6EX5b_Qa20MRrRXi8V5axWzUjDNjPXiKSph9zxHnlsSt5muPfOuXe1mlJMTzysEcJUlyX3M5E3FPDB877q4OYecCrl6Cw5pTzDDL5sf6KfnK7A.webp',4,5),(5,'2024-08-03 13:37:15',0,'https://i.namu.wiki/i/pF2ydeJ4q4jbB6d0hpseI2RjQEfDmx1DGBefpgfG6EX5b_Qa20MRrRXi8V5axWzUjDNjPXiKSph9zxHnlsSt5muPfOuXe1mlJMTzysEcJUlyX3M5E3FPDB877q4OYecCrl6Cw5pTzDDL5sf6KfnK7A.webp',4,5),(6,'2024-08-03 13:37:15',0,'https://i.namu.wiki/i/pF2ydeJ4q4jbB6d0hpseI2RjQEfDmx1DGBefpgfG6EX5b_Qa20MRrRXi8V5axWzUjDNjPXiKSph9zxHnlsSt5muPfOuXe1mlJMTzysEcJUlyX3M5E3FPDB877q4OYecCrl6Cw5pTzDDL5sf6KfnK7A.webp',4,5),(7,'2024-08-09 11:41:40',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',4,7),(8,'2024-08-09 11:41:59',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level2/butterfly.jfif',4,7),(9,'2024-08-09 11:42:13',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/cow.jfif',4,7),(10,'2024-08-09 11:42:49',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/cloud.jfif',4,7),(11,'2024-08-12 16:44:49',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/f1af14dc-dimage.png',4,9),(12,'2024-08-12 17:12:20',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/b3d355e8-4image.png',4,7),(13,'2024-08-12 17:15:13',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/cfc2c70b-0image.png',4,7),(14,'2024-08-12 17:16:20',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/f1f53403-6image.png',4,7),(15,'2024-08-13 13:57:47',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/f52df0a6-fimage.png',10,44),(16,'2024-08-13 15:52:47',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/7aa3febe-3image.png',12,60),(17,'2024-08-13 21:19:12',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/8c76cd4f-9image.png',4,7),(18,'2024-08-13 21:20:09',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/8b5d4e31-7image.png',4,9),(19,'2024-08-13 13:18:39',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,40),(20,'2024-08-13 13:18:40',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,40),(21,'2024-08-13 13:18:40',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,40),(22,'2024-08-13 13:18:41',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,40),(23,'2024-08-13 13:18:41',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,40),(24,'2024-08-13 13:19:14',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,44),(25,'2024-08-13 13:19:14',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,44),(26,'2024-08-13 13:19:14',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,44),(27,'2024-08-13 13:19:14',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,44),(28,'2024-08-13 13:19:14',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/game/word_img/level1/pencil.jfif',10,44),(29,'2024-08-14 04:16:46',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/6a4c0f63-0image.png',4,9),(30,'2024-08-14 04:17:14',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/5232eb54-aimage.png',4,7),(31,'2024-08-14 10:28:07',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/c25d3b33-6image.png',12,60),(32,'2024-08-14 10:42:31',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/5a995706-7image.png',4,7),(33,'2024-08-14 12:10:36',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/bd2fc6bc-4image.png',4,7),(34,'2024-08-14 16:58:40',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/da1973e6-2image.png',4,7),(35,'2024-08-14 17:03:13',1,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/a42b9e06-7image.png',4,7),(37,'2024-08-15 21:09:21',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/de6f37e9-1image.png',4,7),(38,'2024-08-16 03:33:34',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/519434a3-3image.png',4,7),(39,'2024-08-16 04:10:09',0,'https://ko-play.s3.ap-northeast-2.amazonaws.com/image/92a0dc30-6image.png',4,7);
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  9:04:15
